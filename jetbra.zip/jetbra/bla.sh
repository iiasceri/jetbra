cd scripts
sh install.sh
